/**
 * Various relatively generic utilities for data generation and buffering. They are not
 * clearly associated with any particular part of the Mary system and may be
 * reusable in different contexts.
 */
package marytts.util.data;

