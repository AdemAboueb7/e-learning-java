/**
 * Various relatively generic utilities for DOM XML processing. They are not
 * clearly associated with any particular part of the Mary system and may be
 * reusable in different contexts.
 */
package marytts.util.dom;

