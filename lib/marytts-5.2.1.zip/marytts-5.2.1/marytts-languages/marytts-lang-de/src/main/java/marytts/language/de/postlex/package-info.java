/**
 * Internals of the postlexical phonology module.
 */
package marytts.language.de.postlex;

