/**
 * Mary socket client implementation and interface.
 */
package marytts.client;

